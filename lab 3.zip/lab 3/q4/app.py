import json
from flask import Flask, render_template, request, jsonify   

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("InputOutput.html")    
    

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr) 
    
    response = ""
    string=jsonObj["string"]
    string=string.lower()
    
    
    freq = [None] * len(string);  
    maxChar = string[0];  
    for i in range(0, len(string)):  
    	freq[i] = 1;  
    	for j in range(i+1, len(string)):  
        	if(string[i] == string[j] and string[i] != ' ' and string[i] != '0'):  
            		freq[i] = freq[i] + 1;
    max = freq[0];  
    for i in range(0, len(freq)):            
    	if(max < freq[i]):  
        	max = freq[i];  
        	maxChar = string[i];  
    response+="<b>" + maxChar + "</b>"
   
        
    	    
    return response
    
    
if __name__ == "__main__":
    app.run(debug=True)
    
    
