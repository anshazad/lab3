import json
from flask import Flask, render_template, request, jsonify   

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("InputOutput.html")    
    

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr) 
    
    response = ""
    rows=int(jsonObj["rows"])
    currentNumber = 1
    
    for i in range(1,rows+1):
       for column in range( i):
          
          response+="<b> " + str(currentNumber) + " </b>"
          currentNumber += 1

       response+="<br>"

    	    
    return response
    
    
if __name__ == "__main__":
    app.run(debug=True)
    
    
